const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

db.connect((err) => {
  if (err) {
    console.error('❌ Error en la conexión:', err);
    return;
  }
  console.log('✅ Conectado a la base de datos');
});

app.post('/insertar', (req, res) => {
  const { ambiente, temperatura, humedad } = req.body;
  const sql = 'INSERT INTO sip (ambiente, temperatura, humedad) VALUES (?, ?, ?)';
  db.query(sql, [ambiente, temperatura, humedad], (err) => {
    if (err) {
      console.error('❌ Error al insertar:', err);
      return res.status(500).send('Error al guardar');
    }
    res.send('✅ Datos guardados correctamente');
  });
});

app.get('/leer', (req, res) => {
  const sql = 'SELECT * FROM sip ORDER BY id DESC LIMIT 1';
  db.query(sql, (err, result) => {
    if (err) {
      console.error('❌ Error al leer:', err);
      return res.status(500).send('Error al leer');
    }
    res.json(result[0]);
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Servidor SIP corriendo en puerto ${port}`);
});
