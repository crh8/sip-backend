# Smart Indoor Pro (SIP) - Backend

Este proyecto en Node.js permite recibir datos desde sensores de cultivo indoor y almacenarlos en una base de datos MySQL.

## Endpoints

- POST `/insertar`  
  Cuerpo (JSON):  
  ```json
  {
    "ambiente": "A",
    "temperatura": 24.6,
    "humedad": 59
  }
  ```

- GET `/leer`  
  Devuelve el último registro insertado.
